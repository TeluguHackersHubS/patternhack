
echo '                    
            __   __     _____   __       __       _____    
           /\_\ /_/\  /\_____\ /\_\     /\_\     ) ___ (   
          ( ( (_) ) )( (_____/( ( (    ( ( (    / /\_/\ \  
           \ \___/ /  \ \__\   \ \_\    \ \_\  / /_/ (_\ \ 
           / / _ \ \  / /__/_  / / /__  / / /__\ \ )_/ / / 
          ( (_( )_) )( (_____\( (_____(( (_____(\ \/_\/ /  
           \/_/ \_\/  \/_____/ \/_____/ \/_____/ )_____(   
                                                 
' 
echo " "
echo "                             About"
echo " "
echo "       🙏 Hey, there I am Naveen , i made this tool
  to penetrate pattern by link from termux, so i hope guys you
                             liked it. 😘"
echo ""
echo "                  Our channel :- Telugu Hackers Hub"
echo " "
echo "			YouTube    :-  https://bit.ly/2AjKZFh "
echo " "
echo "			Instagram  :-   https://bit.ly/3cbUPpN "
echo " "
echo " 			facebook   :-  https://bit.ly/36E5Te4 " 
echo " " 
echo " 			website    :-  https://bit.ly/2M8S1PJ "
echo " "


printf "\e[1;91m    [\e[0m\e[1;93m1\e[0m\e[1;91m]\e[0m\x1b[38;2;255;100;0m    Main Menu\x1b[0m\n"
read -p $'\n\e[1;94m[\e[0m\e[1;93m*\e[0m\e[1;94m] Choose an option # \e[0m' option

if [[ $option == 1 ]]; then
exit 1
clear
cd $HOME/patternhack/
bash patternhack.Sh
else
clear
cd $HOME/patternhack/
bash patternhack.Sh
done

