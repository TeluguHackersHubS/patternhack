<h1 align="center">Pattern Hack v1.0</h1>
<p align="center">
      A new android pattern lock phishing tool for termux users
</p>

## 🔍 ***About PatternHack***:

hacklock is a bash based script which is officially termux from this tool in just one click you can generate pattern phishing tool which can hack victim pattern and. This tool works on both rooted Android device and Non-rooted Android device.

### 📌 ***Installation and usage guide***:
```
$ apt-get update -y
```
```
$ apt-get upgrade -y
```
```
$ pkg install python -y 
```
```
$ pkg install python2 -y
```
```
$ pkg install git -y
```
```
$ pip install lolcat
```
```
$ git clone https://github.com/TeluguHackersHub/patternhack
```
```
$ ls
```
```
$ cd patternhack
```
```
$ ls
```
```
$ bash patternhack.sh


 📢 Warning 

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
